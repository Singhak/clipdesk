const a=""+new URL("vision_wasm_internal-BWEwtLSW.wasm",import.meta.url).href;export{a as default};
