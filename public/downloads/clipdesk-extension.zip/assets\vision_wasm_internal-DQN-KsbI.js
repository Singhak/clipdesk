const a=""+new URL("vision_wasm_internal-CaWMRP85.js",import.meta.url).href;export{a as default};
