const e=""+new URL("selfie_segmenter-DF05sdL4.tflite",import.meta.url).href;export{e as default};
