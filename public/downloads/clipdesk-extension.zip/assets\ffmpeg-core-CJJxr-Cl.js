const e=""+new URL("ffmpeg-core-CgUfceKH.wasm",import.meta.url).href;export{e as default};
