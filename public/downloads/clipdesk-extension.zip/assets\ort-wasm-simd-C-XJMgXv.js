var m=""+new URL("ort-wasm-simd-DsKU0g1m.wasm",import.meta.url).href;export{m as default};
